package de.uschonha.dateflux;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

public class EasterCalculator {
	
	static public Date getEasterSundayDate(int year) {
		Date result = null;

		int a = year % 19;
		int b = year / 100;
		int c = year % 100;
		int d = b / 4;
		int e = b % 4;
		int f = ( b + 8 ) / 25;
		int g = ( b - f + 1 ) / 3;
		int h = ( 19 * a + b - d - g + 15 ) % 30;
		int i = c / 4;
		int k = c % 4;
		int l = (32 + 2 * e + 2 * i - h - k) % 7;
		int m = (a + 11 * h + 22 * l) / 451;
		int p = (h + l - 7 * m + 114) % 31;

		int month = ( h + l - 7 * m + 114 ) / 31;
		int day = p + 1;

		GregorianCalendar gc = new GregorianCalendar(year, month - 1, day);
		result = gc.getTime();

		return result; 
	}
	
	static public int getCurrentGregorianYear() {
		Calendar cal = new GregorianCalendar();
		return cal.get(Calendar.YEAR);
	}
	
	static public Date getEasterMondayDate(int year) {
		Date sunday = getEasterSundayDate(year);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(sunday);
		cal.add(Calendar.DAY_OF_YEAR, +1);
		return cal.getTime();
	}

	static public Date getGoodFridayDate(int year) {
		Date sunday = getEasterSundayDate(year);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(sunday);
		cal.add(Calendar.DAY_OF_YEAR, -2);
		return cal.getTime();
	}

	static public Date getAscensionDate(int year) {
		Date sunday = getEasterSundayDate(year);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(sunday);
		cal.add(Calendar.DAY_OF_YEAR, +39);
		return cal.getTime();
	}

	static public Date getPentecostMondayDate(int year) {
		Date sunday = getEasterSundayDate(year);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(sunday);
		cal.add(Calendar.DAY_OF_YEAR, +50);
		return cal.getTime();
	}

	static public Date getCorpusChristiDate(int year) {
		Date sunday = getEasterSundayDate(year);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(sunday);
		cal.add(Calendar.DAY_OF_YEAR, +60);
		return cal.getTime();
	}

	static public String getGregorianDateStr(Date aDate) {
		// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd EEE", Locale.US);
		//TODO output string depending on current locale
		SimpleDateFormat sdf = new SimpleDateFormat("MMMM d", Locale.US);
		if (Locale.getDefault().toString().startsWith(Locale.GERMAN.getLanguage())) {
			sdf = new SimpleDateFormat("d. MMMM", Locale.GERMAN);
		} 
		else if (Locale.getDefault().toString().startsWith("es")) {
			sdf = new SimpleDateFormat("d 'de' MMMM", Locale.getDefault());
		}
		return sdf.format(aDate);
	} 

//	/**
//	 * Tested OK against wikipedia article about Easter.
//	 */
//	public static void main(String[] args) {
////		for (int year = 2001; year <= 2021; year++) {
////			System.out.println(getEasterSundayDate(year));
////		}
//		System.out.println(getGregorianDateStr(getGoodFridayDate(2014)));
//		System.out.println(getGregorianDateStr(getEasterSundayDate(2014)));
//		System.out.println(getGregorianDateStr(getEasterMondayDate(2014)));
//	}

}
