package de.uschonha.dateflux;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;

import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.CalendarContract.Events;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.text.TextUtils.TruncateAt;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;

public class DayDetailActivity extends Activity implements OnInitListener, OnDateSetListener {

    public static final String RADIO_ON  = "O";
    public static final String RADIO_OFF = "-";

    public static final String RED_MARKER = "-{R}-";
    public static final String ORANGE_MARKER = "-{O}-";
    public static final String GREEN_MARKER = "-{G}-";
    public static final String BLUE_MARKER = "-{B}-";
    public static final String VIOLET_MARKER = "-{V}-";

    private static final String CHANNEL_ID = "Event";

    static String pickedColor = null;

    Dialog newEventDialog = null;

    private NotificationManager mNotificationManager;

    private static final boolean postReminder = true;

    private static boolean darkMode = false;
    private static final String DARK_MODE = "DARK_MODE";

    private static boolean pitchBlack = true; //TODO idea

    private static boolean gregorianMode = false;
    private static final String GREGORIAN_MODE = "GREGORIAN_MODE";

    private final int[] cellIds = {
            R.id.cell0, R.id.cell1, R.id.cell2, R.id.cell3, R.id.cell4,
            R.id.cell5, R.id.cell6, R.id.cell7, R.id.cell8, R.id.cell9,
            R.id.cell10, R.id.cell11, R.id.cell12, R.id.cell13, R.id.cell14,
            R.id.cell15, R.id.cell16, R.id.cell17, R.id.cell18, R.id.cell19,
            R.id.cell20, R.id.cell21, R.id.cell22, R.id.cell23, R.id.cell24,
            R.id.cell25, R.id.cell26, R.id.cell27, R.id.cell28, R.id.cell29,
            R.id.cell30, R.id.cell31, R.id.cell32, R.id.cell33, R.id.cell34,
            R.id.cell35, R.id.cell36, R.id.cell37, R.id.cell38, R.id.cell39,
            R.id.cell40, R.id.cell41, R.id.cell42, R.id.cell43, R.id.cell44,
            R.id.cell45, R.id.cell46, R.id.cell47, R.id.cell48, R.id.cell49
    };

    /** each its own TTS instance, must not be static! */
    private TextToSpeech myTTS = null;

    /** will be true if TTS setup is ready */
    private boolean myTTSisReady = false;

    /** I guess this is just some arbitrary value */
    private static final int MY_DATA_CHECK_CODE = 2305;

    SharedPreferences        mPrefs;

    DiscordianDate ddate = new DiscordianDate();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day_detail);

        //final Window win = getWindow();
        //WindowManager.LayoutParams lapa = win.getAttributes();
        //lapa.flags += WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION;
        //win.setAttributes(lapa);

        mPrefs = getSharedPreferences("DateFlux", Context.MODE_PRIVATE);
        darkMode = mPrefs.getBoolean(DARK_MODE, false);
        gregorianMode = mPrefs.getBoolean(GREGORIAN_MODE, false);

        fillDDate(R.id.discordianDate);
        fillDayGrid(ddate);
        TextView txtv = (TextView)findViewById(R.id.discordianDate);
        txtv.setOnClickListener(ddateTappedListener);

        setupDayGrid();
    }

    /**
     * Called when the activity is destroyed.
     */
    @Override
    public void onDestroy() {
        System.out.println("## onDestroy called");

        if (myTTS != null) {
            myTTS.stop();
            myTTS.shutdown();
            myTTS = null;
            myTTSisReady = false;
        }
        super.onDestroy();
    }

    /* (non-Javadoc)
     * @see android.app.Activity#onResume()
     */
    @Override
    protected void onResume() {
        System.out.println("## onResume called");
        super.onResume();
        ddate = new DiscordianDate();
        fillDDate(R.id.discordianDate);
        fillDayGrid(ddate);
    }

    private void addRemembranceDay(int day, int month, int year, String txt) {
        Calendar heute = Calendar.getInstance();
        Calendar remDay = Calendar.getInstance();
        remDay.set(Calendar.HOUR_OF_DAY, 0);
        remDay.set(Calendar.MINUTE, 0);
        remDay.set(Calendar.SECOND, 0);
        remDay.set(Calendar.MILLISECOND, 0);
        int currYear = heute.get(Calendar.YEAR); // heute.getTime().getYear() + 1900;
        remDay.set(currYear, month - 1, day);
        int yoldDiff = currYear - year;
        DiscordianDate ddate = new DiscordianDate(remDay.getTime());
        String dateStamp = ddate.getGregorianDateStr();
        System.out.println("## remDay=" + dateStamp);
        String remDayTxt = txt + " (" + yoldDiff + " YOLD ago)";
        if (null == mPrefs.getString(dateStamp, null)) {
            SharedPreferences.Editor mEditor = mPrefs.edit();
            mEditor.putString(dateStamp, remDayTxt);
            mEditor.apply();
        }
    }

    private void fillDDate(int textViewRscId) {
        TextView tv = (TextView)findViewById(textViewRscId);
        String ddateTxt = ddate.getDiscordianWeekday() + ", ";
        ddateTxt += ddate.getDiscordianSeason() + " " + ddate.getDiscordianDayOfSeason() + "\n";
        ddateTxt += "in the YOLD " + ddate.getDiscordianYear() + " ";
        ddateTxt += "(week " + ddate.getDiscordianWeek() + ")\n";
        String holy = ddate.getDiscordianHolyday();
        if (holy != null) {
            ddateTxt += "Celebrate " + holy + "!";
        } else {
            ddateTxt += " ";
        }
        tv.setText(ddateTxt);
        setTitle(ddate.getGregorianDateStr());
        if (darkMode) {
            tv.setTextColor(Color.WHITE);
            tv.setBackgroundColor(0x80000000);
        } else {
            tv.setTextColor(Color.BLACK);
            tv.setBackgroundColor(Color.WHITE);
        }
    }

    OnClickListener colorRadioTappedListener = new OnClickListener() {
        @Override
        public void onClick(View vie) {
            final TextView redTV = (TextView) newEventDialog.findViewById(R.id.myRedTV);
            final TextView orangeTV = (TextView) newEventDialog.findViewById(R.id.myOrangeTV);
            final TextView greenTV = (TextView) newEventDialog.findViewById(R.id.myGreenTV);
            final TextView blueTV = (TextView) newEventDialog.findViewById(R.id.myBlueTV);
            final TextView violetTV = (TextView) newEventDialog.findViewById(R.id.myVioletTV);
            redTV.setText(RADIO_OFF);
            orangeTV.setText(RADIO_OFF);
            greenTV.setText(RADIO_OFF);
            blueTV.setText(RADIO_OFF);
            violetTV.setText(RADIO_OFF);
            ((TextView) vie).setText(RADIO_ON);
            System.out.println("## switched on: " + vie.toString());
            switch (vie.getId()) {
                case R.id.myRedTV:
                    pickedColor = RED_MARKER;
                    break;
                case R.id.myOrangeTV:
                    pickedColor = ORANGE_MARKER;
                    break;
                case R.id.myGreenTV:
                    pickedColor = GREEN_MARKER;
                    break;
                case R.id.myBlueTV:
                    pickedColor = BLUE_MARKER;
                    break;
                case R.id.myVioletTV:
                    pickedColor = VIOLET_MARKER;
                    break;
            }
        }
    };

    private void fillDayGrid(DiscordianDate whichDDate) {
        final Date whichD = whichDDate.getGregorianDate();
        int focusedDay = whichDDate.getDayOfYear();
        final DiscordianDate startDate = new DiscordianDate(whichD);
        int nrOfDayInWeek = whichDDate.getDiscordianWeekdayNr();
        System.out.println("## weekDayNr=" + nrOfDayInWeek);
        startDate.rollDayOfYear(0 - nrOfDayInWeek);
        System.out.println("## start at " + startDate.toString());
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            TextView tvHdr0 = (TextView) findViewById(R.id.hdr0);
            TextView tvHdr1 = (TextView) findViewById(R.id.hdr1);
            TextView tvHdr2 = (TextView) findViewById(R.id.hdr2);
            TextView tvHdr3 = (TextView) findViewById(R.id.hdr3);
            TextView tvHdr4 = (TextView) findViewById(R.id.hdr4);
            if (gregorianMode) {
                final int[] hdrArr = { R.id.hdr0, R.id.hdr1, R.id.hdr2, R.id.hdr3, R.id.hdr4 };
                Date hdrDate = startDate.getGregorianDate();
                final Calendar hdrCal = Calendar.getInstance();
                SimpleDateFormat hdrSdf = new SimpleDateFormat("EEE", Locale.US);
                hdrCal.setTime(hdrDate);
                for (int i = 0; i < hdrArr.length; i++) {
                    String dayStr = hdrSdf.format(hdrDate);
                    TextView tView = (TextView) findViewById(hdrArr[i]);
                    tView.setText(dayStr);
                    hdrCal.add(Calendar.DAY_OF_YEAR, +1);
                    hdrDate = hdrCal.getTime();
                }
            } else {
                tvHdr0.setText("Sm");
                tvHdr1.setText("Bt");
                tvHdr2.setText("Pd");
                tvHdr3.setText("PP");
                tvHdr4.setText("SO");
            }
        }
        DiscordianDate cellDate = startDate;
        int dayToday = new DiscordianDate().getDayOfYear();
        for (int i = 0; i < cellIds.length; i++) {
            TextView tView = (TextView) findViewById(cellIds[i]);
            tView.setTag(cellDate.getGregorianDate());
            if (cellDate.getDayOfYear() == dayToday) {
                tView.setBackgroundColor(getResources().getColor(R.color.myWhite, null));
                tView.setTextColor(Color.BLACK);
            } else {
                if (darkMode) {
                    tView.setTextColor(Color.LTGRAY);
                    tView.setBackgroundColor(0x80000000);
                } else {
                    tView.setTextColor(Color.BLACK);
                    tView.setBackgroundColor(0x80ffffff); // default cell background color
                }
                if (cellDate.getDayOfYear() == focusedDay) {
                    tView.setBackgroundColor(0x30000000);
                }
            }
//			if (cellDate.getDiscordianDayOfSeason() == 40) {
            if (cellDate.getDiscordianHolyday() != null) {
                tView.setText(null);
                tView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_launcher, 0);
                tView.setBackgroundColor(Color.TRANSPARENT);
                if (cellDate.getDayOfYear() == focusedDay) {
                    tView.setBackgroundColor(0x30000000);
                }
            } else { // -><- normal day
                tView.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                if (gregorianMode) {
                    tView.setText("" + cellDate.getDayOfMonth());
                } else {
                    tView.setText("" + cellDate.getDiscordianDayOfSeason());
                }
            }
            if (mPrefs != null) {
                String cellDateGregStr = cellDate.getGregorianDateStr();
                String eventTxt = mPrefs.getString(cellDateGregStr, null);
                if (eventTxt != null) {
                    tView.setTextColor(Color.BLACK);
                    tView.setBackgroundColor(getResources().getColor(R.color.myWhite, null));
                    if (eventTxt.contains(RED_MARKER)) {
                        eventTxt = eventTxt.replace(RED_MARKER, " ");
                        tView.setBackgroundColor(getResources().getColor(R.color.myRed, null));
                    } else if (eventTxt.contains(ORANGE_MARKER)) {
                        eventTxt = eventTxt.replace(ORANGE_MARKER, " ");
                        tView.setBackgroundColor(getResources().getColor(R.color.myOrange, null));
                    } else if (eventTxt.contains(GREEN_MARKER)) {
                        eventTxt = eventTxt.replace(GREEN_MARKER, " ");
                        tView.setBackgroundColor(getResources().getColor(R.color.myGreen, null));
                    } else if (eventTxt.contains(BLUE_MARKER)) {
                        eventTxt = eventTxt.replace(BLUE_MARKER, " ");
                        tView.setBackgroundColor(getResources().getColor(R.color.myBlue, null));
                    } else if (eventTxt.contains(VIOLET_MARKER)) {
                        eventTxt = eventTxt.replace(VIOLET_MARKER, " ");
                        tView.setBackgroundColor(getResources().getColor(R.color.myViolet, null));
                    }
                    if (cellDate.getDiscordianHolyday() == null) {
                        tView.setText(eventTxt);
                        tView.setFocusable(true);
                        if (i < 10) {
                            tView.setFocusedByDefault(true);
                            tView.setHorizontallyScrolling(true);
                        }
                        tView.setFocusableInTouchMode(true);
                        tView.setEllipsize(TruncateAt.MARQUEE);
                    }
                } else { // -><- no event text: reset textView
                    tView.setSelected(false);
                    tView.setFocusable(false);
                    tView.setFocusableInTouchMode(false);
                    tView.setHorizontallyScrolling(false);
                    tView.setEllipsize(null);
                }
            }
            cellDate.rollDayOfYear(+1);
        }
    }

    private void setupDayGrid() {
        for (int i = 0; i < cellIds.length; i++) {
            TextView tView = (TextView) findViewById(cellIds[i]);
            tView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View vie) {
                    Date cellDate = (Date) vie.getTag();
                    ddate = new DiscordianDate(cellDate);
                    fillDDate(R.id.discordianDate);
                    if (mPrefs != null) {
                        String gregStr = ddate.getGregorianDateStr();
                        String eventTxt = mPrefs.getString(gregStr, null);
                        if (eventTxt != null) {
                            if (gregorianMode) {
                                TextView tvDDate = (TextView) findViewById(R.id.discordianDate);
                                tvDDate.setText(removeColorMarker(eventTxt));
                            }
                            Toast.makeText(getApplicationContext(),
                                    "Event '" + eventTxt + "'\n" + gregStr,
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                    fillDayGrid(ddate);
                }
            });
        }
    }

    public static String getWidgetText() {
        DiscordianDate widgDDate = new DiscordianDate();
        String retStr = widgDDate.getDiscordianWeekday() + ", ";
        retStr += widgDDate.getDiscordianSeason() + " " + widgDDate.getDiscordianDayOfSeason() + "\n";
        retStr += "in the YOLD " + widgDDate.getDiscordianYear();
        retStr += " (week " + widgDDate.getDiscordianWeek() + ")";
        String holy = widgDDate.getDiscordianHolyday();
        if (holy != null) {
            retStr += "\nCelebrate " + holy + "!";
        }
        return retStr;
    }

    public static String getWeekdayWidgetText() {
        DiscordianDate widgDDate = new DiscordianDate();
        return widgDDate.getDiscordianWeekday();
    }

    public static String getDiscoDayShortWidgetText() {
        DiscordianDate widgDDate = new DiscordianDate();
        String txt = widgDDate.getDiscordianSeasonShort()
                + " " + widgDDate.getDiscordianDayOfSeason();
        return txt;
    }

    //TODO make use of saved event info if found ?
    public static String getCountdownWidgetText() {
        DiscordianDate widgDDate = new DiscordianDate();
        int daydiff = -1;
        String nextHolyday = "unknown";
        //SharedPreferences mPrefs = getSharedPreferences("DateFlux", Context.MODE_PRIVATE);
        for (int i = 0; i < 50; i++) {
            // look if event is saved
            //String gregDStr = widgDDate.getGregorianDateStr();
            //String eventTxt = mPrefs.getString(gregDStr, null);
            nextHolyday = widgDDate.getDiscordianHolyday();
            if (nextHolyday != null) {
                daydiff = i;
                break; // for loop
            }
            widgDDate.rollDayOfYear(+1);
        }
        String retStr;
        if (daydiff == 0) {
            retStr = "Celebrate\n" + nextHolyday + "!";
        } else if (daydiff == 1) {
            retStr = "Tomorrow is\n" + nextHolyday;
        } else {
            retStr = daydiff + " days until\n" + nextHolyday;
        }
        return retStr;
    }

    /**
     * should be called when TTS check is OK
     */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == MY_DATA_CHECK_CODE) {
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {
                // success, create the TTS instance
                try {
                    myTTS = new TextToSpeech(this, this);
                } catch (Exception exc) {
                    myTTS = null;
                    myTTSisReady = false;
                }
            } else {
                // TODO received an exception stack trace here
                // missing data, install it
                // Intent installIntent = new Intent();
                // installIntent.setAction(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                // startActivity(installIntent);
                Toast.makeText(getApplicationContext(),
                        "No Text-to-Speech-Engine found.", Toast.LENGTH_LONG).show();
                myTTS = null;
                myTTSisReady = false;
            }
        }
    }

    /**
     * start activity when tapping textView
     */
    private OnClickListener ddateTappedListener = new OnClickListener() {
        public void onClick(View vie) {
            if (myTTS == null) { // try to get a reference
                try { // -><- check presence of TTS stuff
                    Intent checkIntent = new Intent();
                    checkIntent.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
                    startActivityForResult(checkIntent, MY_DATA_CHECK_CODE);
                } catch (ActivityNotFoundException anfex) {
                    // anfex.printStackTrace();
                    myTTS = null;
                    myTTSisReady = false;
                }
            }

            final TextView quView = (TextView) findViewById(R.id.discordianDate);
            if (myTTS != null && myTTSisReady) {
                myTTS.speak((String) quView.getText(), TextToSpeech.QUEUE_FLUSH, null);
            }
        }
    };

    /**
     * called when TTS engine is fully loaded and ready for usage
     */
    public void onInit(int arg0) {
        // show nice speaker icon?
        try {
            myTTS.setLanguage(Locale.US);
            myTTS.setPitch(0.7f);
            myTTSisReady = true;
            Toast.makeText(getApplicationContext(), "Text-to-Speech activated.",
                    Toast.LENGTH_LONG).show();
        } catch (Exception exc) {
            myTTS = null;
            myTTSisReady = false;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.day_detail, menu);
        return true;
    }

    @Override
    public boolean onMenuItemSelected(int featureId, MenuItem item) {
        switch (item.getItemId()) {

            case R.id.today_menu_item:
                ddate = new DiscordianDate();
                fillDDate(R.id.discordianDate);
                fillDayGrid(ddate);
                return true;

            case R.id.dark_mode_menu_item:
                darkMode = !darkMode;
                ddate = new DiscordianDate();
                fillDDate(R.id.discordianDate);
                fillDayGrid(ddate);
                SharedPreferences.Editor mEditor2 = mPrefs.edit();
                mEditor2.putBoolean(DARK_MODE, darkMode);
                mEditor2.apply();
                return true;

            case R.id.gregorian_mode_menu_item:
                gregorianMode = !gregorianMode;
                ddate = new DiscordianDate();
                fillDDate(R.id.discordianDate);
                fillDayGrid(ddate);
                SharedPreferences.Editor mEditor3 = mPrefs.edit();
                mEditor3.putBoolean(GREGORIAN_MODE, gregorianMode);
                mEditor3.apply();
                return true;

            case R.id.pick_date_menu_item:
                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getFragmentManager(), "datePicker");
                return true;

            case R.id.share_menu_item:
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_SUBJECT, "DateFlux Discordian Calendar");
                share.putExtra(Intent.EXTRA_TEXT, ddate.toString() );
                startActivity(Intent.createChooser(share, "Share DDate via"));
                return true;

            case R.id.export_menu_item:
                final int ONE_HOUR_IN_MSEC = 1000 * 60 * 60;
                Date theDate = ddate.getGregorianDate();
                String title = ddate.toString();
                String holy = ddate.getDiscordianHolyday();
                if (holy != null) {
                    title = holy + " (Discordian Holyday)";
                }
                final String whichDateStr2 = ddate.getGregorianDateStr();
                String terminStr = mPrefs.getString(whichDateStr2, null);
                if (terminStr != null) {
                    title = terminStr;
                }
                long msecOffset = getMsecOffsetMidnight(title);
                //TODO if timeOfDay found, use it
                long beginTime = ONE_HOUR_IN_MSEC * 9;
                long  endTime = ONE_HOUR_IN_MSEC * 10;
                if (msecOffset > 0) {
                    beginTime = msecOffset;
                    endTime = msecOffset + ONE_HOUR_IN_MSEC;
                    title = title.substring(6);
                }
                title = removeColorMarker(title);
                System.out.println("## event title='" + title + "'");
                Intent intent = new Intent(Intent.ACTION_INSERT)
                        .setData(Events.CONTENT_URI)
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, theDate.getTime() + beginTime)
                        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME,  theDate.getTime() + endTime)
                        // .putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, true)
                        .putExtra(Events.TITLE, title)
                        .putExtra(Events.DESCRIPTION, ddate.toString())
                        // .putExtra(Events.EVENT_LOCATION, "The gym")
                        .putExtra(Events.AVAILABILITY, Events.AVAILABILITY_FREE)
                        // .putExtra(Intent.EXTRA_EMAIL, "rowan@example.com,trevor@example.com")
                        // .putExtra(Events.HAS_ALARM, 0)
                        ;
                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException anfex) {
                    Toast.makeText(getApplicationContext(),
                            "Can't find Google Calendar App.", Toast.LENGTH_LONG).show();
                }
                return true;

            case R.id.new_event_menu_item:
                pickedColor = null;
                newEventDialog = createNewEventDialog();
                newEventDialog.show();

                TextView redTV = (TextView) newEventDialog.findViewById(R.id.myRedTV);
                redTV.setOnClickListener(colorRadioTappedListener);
                TextView orangeTV = (TextView) newEventDialog.findViewById(R.id.myOrangeTV);
                orangeTV.setOnClickListener(colorRadioTappedListener);
                TextView greenTV = (TextView) newEventDialog.findViewById(R.id.myGreenTV);
                greenTV.setOnClickListener(colorRadioTappedListener);
                TextView blueTV = (TextView) newEventDialog.findViewById(R.id.myBlueTV);
                blueTV.setOnClickListener(colorRadioTappedListener);
                TextView violetTV = (TextView) newEventDialog.findViewById(R.id.myVioletTV);
                violetTV.setOnClickListener(colorRadioTappedListener);

                return true;

            case R.id.delete_event_menu_item:
                final String whichDateStr = ddate.getGregorianDateStr();
                if (mPrefs.contains(whichDateStr)) {
                    SharedPreferences.Editor mEditor = mPrefs.edit();
                    mEditor.remove(whichDateStr);
                    mEditor.apply();
                    fillDayGrid(ddate);
                    Toast.makeText(getApplicationContext(),
                            "Removed Event " + whichDateStr, Toast.LENGTH_LONG).show();
                    try {
                        mNotificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
                        mNotificationManager.cancel(whichDateStr.hashCode());
                    } catch (NullPointerException npex) {
                        System.out.println("## deleted event notif.");
                    }
                } else {
                    Toast.makeText(getApplicationContext(),
                            "There's no Event on " + whichDateStr, Toast.LENGTH_LONG).show();
                }
                return true;

            case R.id.christian_holidays_menu_item:
                Dialog chriDia = christianHolidaysDialog();
                chriDia.show();
                return true;

            default:
                break;
        }
        return super.onMenuItemSelected(featureId, item);
    }

    private String removeColorMarker(String str) {
        str = str.replace(RED_MARKER, "");
        str = str.replace(ORANGE_MARKER, "");
        str = str.replace(GREEN_MARKER, "");
        str = str.replace(BLUE_MARKER, "");
        str = str.replace(VIOLET_MARKER, "");
        return str;
    }

    /**
     * Get millisecs from appointment string.
     * @param str Appointment String starting with 24 hour time of day,
     *            for example "18:30 Shopping".
     * @return msecs when time found, 0 if not or error occurred.
     */
    private long getMsecOffsetMidnight(String str) {
        long msec = 0;
        if (str != null && str.length() >= 8) {
            String timeStr = str.substring(0, 5);
            String[] strArr = timeStr.split(":");
            if (strArr != null && strArr.length == 2) {
                int hour = Integer.parseInt(strArr[0]);
                int min  = Integer.parseInt(strArr[1]);
                if (hour >= 0 && hour <= 23) {
                    if (min >= 0 && min <= 59) {
                        final int MINUTE = 1000 * 60;
                        msec = (hour * 60 * MINUTE) + (min * MINUTE);
                        System.out.println("## hr=" + hour + ", min=" + min
                                + ": msec=" + msec);
                    }
                }
            }
        }
        return msec;
    }

    public Dialog christianHolidaysDialog() {
        final int currGregYear = EasterCalculator.getCurrentGregorianYear();
        final String categoryStr = " (christian holiday)";
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder
                .setTitle("Christian Holidays")
                .setIcon(R.drawable.ic_launcher)
                .setMessage("Do you want to add Christian Holidays " + currGregYear + " to your Calendar?")
                // Add action buttons
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        Date goodFriday   = EasterCalculator.getGoodFridayDate(currGregYear);
                        //Date easterSunday = EasterCalculator.getEasterSundayDate(currGregYear);
                        Date easterMonday = EasterCalculator.getEasterMondayDate(currGregYear);
                        Date ascension    = EasterCalculator.getAscensionDate(currGregYear);
                        Date pentecost    = EasterCalculator.getPentecostMondayDate(currGregYear);
                        Date corpusChrist = EasterCalculator.getCorpusChristiDate(currGregYear);
                        SharedPreferences.Editor mEditor = mPrefs.edit();
                        mEditor.putString(DiscordianDate.getGregorianDateKeyStr(goodFriday),   "Good Friday"   + categoryStr);
                        //mEditor.putString(DiscordianDate.getGregorianDateKeyStr(easterSunday), "Easter Sunday" + categoryStr);
                        mEditor.putString(DiscordianDate.getGregorianDateKeyStr(easterMonday), "Easter Monday" + categoryStr);
                        mEditor.putString(DiscordianDate.getGregorianDateKeyStr(ascension),    "Ascension"     + categoryStr);
                        mEditor.putString(DiscordianDate.getGregorianDateKeyStr(pentecost), "Pentecost Monday" + categoryStr);
                        mEditor.putString(DiscordianDate.getGregorianDateKeyStr(corpusChrist), "Corpus Christi" + categoryStr);
                        mEditor.apply();
                        // addRemembranceDay(27, 11, 2000, "Test Remembrance Day");
                        addRemembranceDay(20,  7, 2000, "Malaclypse the Younger Remembrance Day");
                        addRemembranceDay(28, 11, 1998, "Omar Khayyam Ravenhurst Remembrance Day");
                        addRemembranceDay(11,  1, 2007, "Mordecai Malignatus Remembrance Day");
                        addRemembranceDay( 8,  1, 1880, "Emperor Norton Remembrance Day");
                        // addRemembranceDay(, , , " Remembrance Day");
                        Toast.makeText(getApplicationContext(),
                                "Christian Holidays saved.", Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        return builder.create();
    }

    public Dialog createNewEventDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // Get the layout inflater
        LayoutInflater inflater = this.getLayoutInflater();
        // Inflate and set the layout for the dialog
        final View eventView = inflater.inflate(R.layout.eventdialog, null);
        // Pass null as the parent view because its going in the dialog layout
        builder.setView(eventView)
                // Add action buttons
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        final String whichDateStr = ddate.getGregorianDateStr();
                        EditText etxt = (EditText) eventView.findViewById(R.id.eventdescr);
                        CheckBox chkBox = (CheckBox) eventView.findViewById(R.id.repeatCheckBox);
                        String txt = etxt.getText().toString();
                        if (pickedColor != null) {
                            txt += " " + pickedColor;
                        }
                        System.out.println("## event text='" + txt + "'");
                        if (txt != null && txt.length() > 0) {
                            SharedPreferences.Editor mEditor = mPrefs.edit();
                            mEditor.putString(whichDateStr, txt);
                            if (chkBox.isChecked()) { // repeat 10 years
                                DiscordianDate newDDate = new DiscordianDate(ddate.getGregorianDate()); // copy?!
                                for (int i = 0; i < 10; i++) {
                                    newDDate.rollYear(+1);
                                    String newDDateStr = newDDate.getGregorianDateStr();
                                    mEditor.putString(newDDateStr, txt);
                                    System.out.println("## saved " + newDDateStr);
                                }
                            }
                            mEditor.apply();
                            Toast.makeText(getApplicationContext(),
                                    "Event '" + txt + "' saved.", Toast.LENGTH_LONG).show();
                            if (postReminder) {
                                createNotificationChannel();
                                sendNotification(whichDateStr, txt);
                            }
                        }
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        return builder.create();
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int day) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month, day);
        Date pickedDate = cal.getTime();
        ddate = new DiscordianDate(pickedDate);
        fillDDate(R.id.discordianDate);
        fillDayGrid(ddate);
    }

    /**
     * Post a notification.
     *
     * @param msg Text string msg content.
     */
    private void sendNotification(String title, String msg) {
        mNotificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, DayDetailActivity.class), 0);

        Notification.Builder mBuilder =
                new Notification.Builder(this, CHANNEL_ID)
                        .setGroup(getString(R.string.app_name))
                        .setSmallIcon(R.drawable.ic_launcher)
                        .setContentTitle(title)
                        .setStyle(new Notification.BigTextStyle().bigText(msg))
                        .setContentText(removeColorMarker(msg));

        try {
            final long msecOffset = getMsecOffsetMidnight(msg);
            final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd EEE", Locale.US);
            final Date tDate = sdf.parse(title);
            mBuilder.setWhen(tDate.getTime() + msecOffset);
            mBuilder.setUsesChronometer(true);

        } catch (ParseException pex) {
            // nix
        } catch (NullPointerException npx) {
            // nix
        }

        if (msg.contains(RED_MARKER)) {
            mBuilder.setColor(getResources().getColor(R.color.myRed, null));
        }
        if (msg.contains(ORANGE_MARKER)) {
            mBuilder.setColor(getResources().getColor(R.color.myOrange, null));
        }
        if (msg.contains(GREEN_MARKER)) {
            mBuilder.setColor(getResources().getColor(R.color.myGreen, null));
        }
        if (msg.contains(BLUE_MARKER)) {
            mBuilder.setColor(getResources().getColor(R.color.myBlue, null));
        }
        if (msg.contains(VIOLET_MARKER)) {
            mBuilder.setColor(getResources().getColor(R.color.myViolet, null));
        }

        mBuilder.setContentIntent(contentIntent);
        mNotificationManager.notify(title.hashCode(), mBuilder.build());
    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

}
