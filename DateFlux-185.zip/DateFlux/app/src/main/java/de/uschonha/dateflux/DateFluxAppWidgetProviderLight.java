package de.uschonha.dateflux;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/**
 * My first Android widget
 */
public class DateFluxAppWidgetProviderLight extends AppWidgetProvider {

	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
		final int N = appWidgetIds.length;

		// Perform this loop procedure for each App Widget that belongs to this provider
		for (int i = 0; i < N; i++) {
			int appWidgetId = appWidgetIds[i];

			// Get the layout for the App Widget and attach an on-click listener to the button
			RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.ddate_appwidget_light);

			// Create an Intent to launch Quote Quiz activity
			Intent intent = new Intent(context, DayDetailActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.setAction("NO CACHE: " + System.currentTimeMillis());
			PendingIntent pendingIntent = PendingIntent.getActivity(context, appWidgetId, intent, 0);
			// views.setOnClickPendingIntent(R.id.ff_icon_widget, pendingIntent);

			final String newQuote = DayDetailActivity.getWidgetText();
			views.setTextViewText(R.id.ddate_text_view_widget_light, newQuote);

//			Intent intentRead = new Intent(context, DayDetailActivity.class);
//			intentRead.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
//			PendingIntent pendingReader = PendingIntent.getActivity(context, 0, intentRead, 0);
			views.setOnClickPendingIntent(R.id.ddate_text_view_widget_light, pendingIntent);

			// Tell the AppWidgetManager to perform an update on the current App Widget
			appWidgetManager.updateAppWidget(appWidgetId, views);
		}
	}

}
